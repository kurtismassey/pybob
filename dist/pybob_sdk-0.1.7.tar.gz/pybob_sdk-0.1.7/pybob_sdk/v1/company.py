class Company:
    pass
